package com.udacity.sandwichclub.utils;

import com.udacity.sandwichclub.model.Sandwich;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class JsonUtils {

    public static Sandwich parseSandwichJson(String json) {
        JSONObject jsonObject;
        Sandwich returnSandwich = new Sandwich();
        try {
            jsonObject = new JSONObject(json);

            JSONObject name = jsonObject.getJSONObject("name");

            returnSandwich.setMainName(name.getString("mainName"));

            JSONArray akaNamesJsonArray = name.getJSONArray("alsoKnownAs");
            List<String> akaNamesList = new ArrayList<>();
            for (int i = 0; i < akaNamesJsonArray.length(); i++) {
                akaNamesList.add(akaNamesJsonArray.getString(i));
            }
            returnSandwich.setAlsoKnownAs(akaNamesList);

            returnSandwich.setPlaceOfOrigin(jsonObject.getString("placeOfOrigin"));

            returnSandwich.setDescription(jsonObject.getString("description"));

            returnSandwich.setImage(jsonObject.getString("image"));

            JSONArray ingredientsJsonArray = jsonObject.getJSONArray("ingredients");
            List<String> ingredientsList = new ArrayList<>();
            for (int i = 0; i < ingredientsJsonArray.length(); i++) {
                ingredientsList.add(ingredientsJsonArray.getString(i));
            }
            returnSandwich.setIngredients(ingredientsList);

//            List<String> ingredientsList = new ArrayList<>();
//            ingredientsList.add("One");
//            ingredientsList.add("Two");
//            ingredientsList.add("Three");
//            returnSandwich.setIngredients(ingredientsList);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return returnSandwich;
    }
}
